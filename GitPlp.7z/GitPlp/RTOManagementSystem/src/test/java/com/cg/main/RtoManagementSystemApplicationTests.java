package com.cg.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtoManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
