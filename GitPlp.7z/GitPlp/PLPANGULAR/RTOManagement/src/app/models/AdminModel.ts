export class AdminModel {
  id: string;
  adminName: string;
  email: string;
  password: string;
}
