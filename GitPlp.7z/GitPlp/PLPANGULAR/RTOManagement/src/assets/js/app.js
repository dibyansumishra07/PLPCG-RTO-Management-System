alert("hello world");

new fullpage("#fullpage", {
  autoScrolling: true,
});
